
import streamlit as st
from utils.auth import signup_user, login_user, send_password_reset, change_user_email
from utils.chat import call_gpt_with_functions, handle_custom_features
from utils.file_upload import handle_file_upload
from utils.stripe_checkout import show_pricing_page

st.set_page_config(page_title="📚 BooklinQ AI", layout="wide")

# --- Session Initialization ---
if 'authenticated' not in st.session_state:
    st.session_state.authenticated = False

# --- Navigation ---
st.sidebar.title("🔐 BooklinQ")
page = st.sidebar.selectbox("Navigate", ["Login", "Signup", "Chat Assistant", "File Upload", "Pricing", "Reset Password", "Change Email"])

# --- LOGIN ---
if page == "Login":
    email = st.sidebar.text_input("Email")
    password = st.sidebar.text_input("Password", type="password")
    if st.sidebar.button("Login"):
        user, error = login_user(email, password)
        if user:
            st.session_state.authenticated = True
            st.success("Login successful!")
        else:
            st.error(f"Login failed: {error}")

# --- SIGNUP ---
elif page == "Signup":
    name = st.sidebar.text_input("Full Name")
    phone = st.sidebar.text_input("Phone Number")
    email = st.sidebar.text_input("Email")
    password = st.sidebar.text_input("Password", type="password")
    if st.sidebar.button("Sign Up"):
        user, error = signup_user(name, phone, email, password)
        if user:
            st.success("Signup successful! Verify email before login.")
        else:
            st.error(f"Signup failed: {error}")

# --- PASSWORD RESET ---
elif page == "Reset Password":
    email = st.sidebar.text_input("Enter email to reset")
    if st.sidebar.button("Send Reset Link"):
        success, error = send_password_reset(email)
        if success:
            st.success("Reset email sent.")
        else:
            st.error(f"Error: {error}")

# --- CHANGE EMAIL ---
elif page == "Change Email":
    user_token = st.sidebar.text_input("User Token")
    new_email = st.sidebar.text_input("New Email")
    if st.sidebar.button("Update Email"):
        success, error = change_user_email(user_token, new_email)
        if success:
            st.success("Email updated successfully.")
        else:
            st.error(f"Error: {error}")

# --- CHAT ASSISTANT ---
elif page == "Chat Assistant" and st.session_state.authenticated:
    st.header("💬 AI Chat Assistant")
    user_input = st.text_area("Ask me anything...", height=150)
    if st.button("Send"):
        prompt = handle_custom_features(user_input)
        response = call_gpt_with_functions([{"role": "user", "content": prompt}])
        st.markdown("**Assistant:**")
        st.write(response.get("content", "No response."))

# --- FILE UPLOAD ---
elif page == "File Upload" and st.session_state.authenticated:
    st.header("📤 Upload Files for Analysis")
    handle_file_upload()

# --- PRICING PAGE ---
elif page == "Pricing":
    show_pricing_page()

# --- Unauthenticated Access Block ---
elif not st.session_state.authenticated and page in ["Chat Assistant", "File Upload"]:
    st.warning("Please login to access this feature.")
