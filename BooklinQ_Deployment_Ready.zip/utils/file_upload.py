# utils/file_upload.py
import streamlit as st

ALLOWED_TYPES = ["text/plain", "application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"]

def handle_file_upload():
    uploaded_file = st.file_uploader("Upload a file", type=None)
    if uploaded_file:
        if uploaded_file.type in ALLOWED_TYPES:
            st.success(f"Uploaded: {uploaded_file.name}")
            file_content = uploaded_file.read()
            st.write("Preview:")
            if uploaded_file.type == "text/plain":
                st.text(file_content.decode("utf-8"))
            else:
                st.info("Preview not supported for this file type.")
        else:
            st.error("Unsupported file type. Please upload a TXT, PDF, or DOCX file.")
