from utils.platform_apis import fetch_sage_data, record_sage_transaction

def call_accounting_function(name, args):
    if name == "fetch_data_from_platform":
        platform = args.get("platform", "").lower()
        data_type = args.get("data_type", "").lower()
        if platform == "sage":
            return fetch_sage_data(data_type)
        else:
            return f"Platform '{platform}' not supported yet."

    elif name == "record_transaction_to_platform":
        platform = args.get("platform", "").lower()
        tx_type = args.get("transaction_type", "")
        details = args.get("details", {})
        if platform == "sage":
            return record_sage_transaction(tx_type, details)
        else:
            return f"Platform '{platform}' not supported yet."

    else:
        return "Unknown function call."

accounting_functions = [
    {
        "type": "function",
        "function": {
            "name": "fetch_data_from_platform",
            "description": "Fetches invoices, clients, or expenses from a connected accounting platform.",
            "parameters": {
                "type": "object",
                "properties": {
                    "platform": {
                        "type": "string",
                        "enum": ["sage", "xero", "quickbooks"]
                    },
                    "data_type": {
                        "type": "string",
                        "enum": ["invoices", "clients", "expenses"]
                    }
                },
                "required": ["platform", "data_type"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "record_transaction_to_platform",
            "description": "Records a new transaction (expense/income) to an accounting platform.",
            "parameters": {
                "type": "object",
                "properties": {
                    "platform": {
                        "type": "string",
                        "enum": ["sage", "xero", "quickbooks"]
                    },
                    "transaction_type": {
                        "type": "string",
                        "enum": ["income", "expense"]
                    },
                    "details": {
                        "type": "object"
                    }
                },
                "required": ["platform", "transaction_type", "details"]
            }
        }
    }
]
