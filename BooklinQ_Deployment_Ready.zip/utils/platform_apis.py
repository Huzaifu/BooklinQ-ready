import random

# Mock Sage API functions
def fetch_sage_data(data_type):
    mock_data = {
        "invoices": ["Invoice A", "Invoice B"],
        "clients": ["Client X", "Client Y"],
        "expenses": ["Expense 1", "Expense 2"]
    }
    return mock_data.get(data_type.lower(), [])

def record_sage_transaction(transaction_type, details):
    return {
        "status": "success",
        "message": f"{transaction_type.capitalize()} recorded to Sage with ID #{random.randint(1000, 9999)}"
    }

# (Optional) Add Xero and QuickBooks logic here
