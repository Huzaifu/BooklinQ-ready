
import streamlit as st
import openai
import os
import json
import pyttsx3
import threading
from dotenv import load_dotenv
from utils.accounting_functions import call_accounting_function, accounting_functions

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

# Initialize Text-to-Speech
engine = pyttsx3.init()

def speak(text: str):
    try:
        def run():
            engine.say(text)
            engine.runAndWait()
        threading.Thread(target=run).start()
    except Exception as e:
        print(f"TTS Error: {e}")

def call_gpt_with_functions(messages: list) -> dict:
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4-1106-preview",
            messages=messages,
            tools=accounting_functions,
            tool_choice="auto"
        )
        choices = response.get("choices", [])
        if choices and "message" in choices[0]:
            return choices[0]["message"]
        else:
            raise ValueError("No valid response from GPT-4")
    except Exception as e:
        return {"role": "assistant", "content": f"Error calling GPT: {str(e)}"}

def handle_custom_features(user_input: str) -> str:
    prompt_map = {
        "summarize": "Summarize the following text:\n{}",
        "email": "Write a professional email about:\n{}",
        "letter": "Draft a formal letter or application regarding:\n{}",
        "interview": "Provide potential interview questions for:\n{}",
        "quiz": "Create a quiz based on this topic:\n{}",
        "tutor": "Explain this concept clearly:\n{}"
    }
    for key, prompt_template in prompt_map.items():
        if key in user_input.lower():
            return prompt_template.format(user_input)
    return user_input
