# integrations/quickbooks.py
import requests
import os
from dotenv import load_dotenv

load_dotenv()

CLIENT_ID = os.getenv("QB_CLIENT_ID")
CLIENT_SECRET = os.getenv("QB_CLIENT_SECRET")
REFRESH_TOKEN = os.getenv("QB_REFRESH_TOKEN")
REALM_ID = os.getenv("QB_REALM_ID")
BASE_URL = "https://sandbox-quickbooks.api.intuit.com/v3/company/"

# Step 1: Get a new access token using refresh token
def get_access_token():
    url = "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer"
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded"
    }
    data = {
        "grant_type": "refresh_token",
        "refresh_token": REFRESH_TOKEN
    }
    response = requests.post(url, headers=headers, data=data, auth=(CLIENT_ID, CLIENT_SECRET))
    response.raise_for_status()
    return response.json()["access_token"]

# Step 2: Fetch data (invoices, customers, etc.)
def fetch_data(data_type="invoices"):
    token = get_access_token()
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json"
    }
    endpoint = {
        "invoices": f"{BASE_URL}{REALM_ID}/query?query=select * from Invoice",
        "clients": f"{BASE_URL}{REALM_ID}/query?query=select * from Customer",
        "expenses": f"{BASE_URL}{REALM_ID}/query?query=select * from Purchase"
    }
    url = endpoint.get(data_type.lower())
    if not url:
        raise ValueError("Unsupported data type")

    res = requests.get(url, headers=headers)
    res.raise_for_status()
    return res.json()

# Step 3: Record a transaction

def record_transaction(amount, description, category):
    token = get_access_token()
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    url = f"{BASE_URL}{REALM_ID}/purchase"
    body = {
        "AccountRef": {"value": "1"},  # default account for demo
        "PaymentType": "Cash",
        "Line": [{
            "Amount": amount,
            "DetailType": "AccountBasedExpenseLineDetail",
            "AccountBasedExpenseLineDetail": {
                "AccountRef": {"value": "1"},
                "TaxCodeRef": {"value": "TAX"}
            },
            "Description": description
        }],
        "EntityRef": {
            "type": "Vendor",
            "value": "1"  # default vendor
        }
    }
    response = requests.post(url, headers=headers, json=body)
    response.raise_for_status()
    return response.json()
