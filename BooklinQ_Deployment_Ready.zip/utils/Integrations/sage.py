# integrations/sage.py
import requests
import os
from dotenv import load_dotenv

load_dotenv()

SAGE_ACCESS_TOKEN = os.getenv("SAGE_ACCESS_TOKEN")
SAGE_BASE_URL = "https://api.accounting.sage.com/v3.1"

# Fetch data (sales_invoices, contacts, purchase_invoices)
def fetch_data(data_type="invoices"):
    headers = {
        "Authorization": f"Bearer {SAGE_ACCESS_TOKEN}",
        "Accept": "application/json"
    }
    endpoints = {
        "invoices": f"{SAGE_BASE_URL}/sales_invoices",
        "clients": f"{SAGE_BASE_URL}/contacts",
        "expenses": f"{SAGE_BASE_URL}/purchase_invoices"
    }
    url = endpoints.get(data_type.lower())
    if not url:
        raise ValueError("Unsupported data type")

    res = requests.get(url, headers=headers)
    res.raise_for_status()
    return res.json()

# Record a new purchase invoice (basic expense entry)
def record_transaction(amount, description, category):
    headers = {
        "Authorization": f"Bearer {SAGE_ACCESS_TOKEN}",
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    url = f"{SAGE_BASE_URL}/purchase_invoices"
    body = {
        "purchase_invoice": {
            "contact_id": "your_contact_id",  # must be a valid contact in your Sage org
            "date": "2024-01-01",
            "due_date": "2024-01-15",
            "reference": description,
            "invoice_lines": [
                {
                    "description": description,
                    "ledger_account_id": "your_account_id",  # map to category
                    "quantity": 1,
                    "unit_price": amount
                }
            ]
        }
    }
    response = requests.post(url, headers=headers, json=body)
    response.raise_for_status()
    return response.json()
