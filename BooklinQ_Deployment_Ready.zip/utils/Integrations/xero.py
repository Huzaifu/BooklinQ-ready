# integrations/xero.py
import requests
import os
from dotenv import load_dotenv

load_dotenv()

CLIENT_ID = os.getenv("XERO_CLIENT_ID")
CLIENT_SECRET = os.getenv("XERO_CLIENT_SECRET")
REFRESH_TOKEN = os.getenv("XERO_REFRESH_TOKEN")
TENANT_ID = os.getenv("XERO_TENANT_ID")

# Get access token from refresh token
def get_access_token():
    url = "https://identity.xero.com/connect/token"
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    data = {
        "grant_type": "refresh_token",
        "refresh_token": REFRESH_TOKEN,
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET
    }
    response = requests.post(url, headers=headers, data=data)
    response.raise_for_status()
    return response.json()["access_token"]

# Fetch data (invoices, contacts, bank transactions)
def fetch_data(data_type="invoices"):
    token = get_access_token()
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "Xero-tenant-id": TENANT_ID
    }
    endpoints = {
        "invoices": "https://api.xero.com/api.xro/2.0/Invoices",
        "clients": "https://api.xero.com/api.xro/2.0/Contacts",
        "expenses": "https://api.xero.com/api.xro/2.0/BankTransactions"
    }
    url = endpoints.get(data_type.lower())
    if not url:
        raise ValueError("Unsupported data type")

    res = requests.get(url, headers=headers)
    res.raise_for_status()
    return res.json()

# Record a new bank transaction (basic cash expense)
def record_transaction(amount, description, category):
    token = get_access_token()
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Xero-tenant-id": TENANT_ID
    }
    url = "https://api.xero.com/api.xro/2.0/BankTransactions"
    body = {
        "Type": "SPEND",
        "Contact": {"Name": "Demo Vendor"},
        "LineItems": [
            {
                "Description": description,
                "Quantity": 1.0,
                "UnitAmount": amount,
                "AccountCode": category or "400"
            }
        ],
        "BankAccount": {
            "Code": "090"
        }
    }
    response = requests.post(url, headers=headers, json={"BankTransactions": [body]})
    response.raise_for_status()
    return response.json()
