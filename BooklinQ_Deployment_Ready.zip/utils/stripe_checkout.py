# utils/stripe_checkout.py
import streamlit as st
import stripe
import os

# Set your secret key from environment variables or Streamlit secrets
stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "sk_test_51RRUa0CE9fjcDsjttHZrTMO3wlgxLrk8amkYLm1RDtsV1WaTEtKjD9M85Di79NRJlPfggdvNhllMSUs5eJCHVywy00Zg518dKB")  # Replace with your secret key securely

# Stripe price IDs (from your Stripe dashboard)
TIER_PRICE_ID = os.getenv("STRIPE_TIER_PRICE_ID", "price_1RSY4lCE9fjcDsjtraIM9yOD")
PREMIUM_PRICE_ID = os.getenv("STRIPE_PREMIUM_PRICE_ID", "price_1RSY4lCE9fjcDsjtraIM9yOD")

DOMAIN = os.getenv("DOMAIN", "http://localhost:8501")  # Streamlit app domain

def show_pricing_page():
    st.title("💳 Choose a Subscription Plan")

    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Tier Plan")
        st.markdown("**$5/month**")
        st.markdown("- Basic chat access\n- Limited file uploads")
        if st.button("Subscribe Tier"):
            checkout_session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[{
                    'price': TIER_PRICE_ID,
                    'quantity': 1,
                }],
                mode='subscription',
                success_url=f"{DOMAIN}?session_id={{CHECKOUT_SESSION_ID}}",
                cancel_url=f"{DOMAIN}",
            )
            st.markdown(f"[Click here to pay]({checkout_session.url})")

    with col2:
        st.subheader("Premium Plan")
        st.markdown("**$15/month**")
        st.markdown("- Priority chat access\n- Unlimited file uploads")
        if st.button("Subscribe Premium"):
            checkout_session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[{
                    'price': PREMIUM_PRICE_ID,
                    'quantity': 1,
                }],
                mode='subscription',
                success_url=f"{DOMAIN}?session_id={{CHECKOUT_SESSION_ID}}",
                cancel_url=f"{DOMAIN}",
            )
            st.markdown(f"[Click here to pay]({checkout_session.url})")
