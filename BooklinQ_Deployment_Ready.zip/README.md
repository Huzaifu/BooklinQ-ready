# Smart-Account-AI 🤖📊

A smart accounting assistant built with Streamlit, OpenAI GPT-4 Turbo, Firebase Auth, and voice capabilities.

## 🔑 Key Features

- Email/password + Google sign-in with Firebase
- Email verification and password reset
- Voice-enabled AI assistant (Text-to-Speech)
- Accounting-specific GPT-4 Turbo function calling
- Interview simulation mode
- Summarizer, Letter, Email, Expense Analyzer, Budget planner
- Profit & Loss generator, Cash Flow analysis
- Tax calculator, Depreciation calculator
- Inventory & Payroll management summaries
- Currency conversion and quiz mode
- AI Tutor for explaining accounting concepts
- Secure and extensible backend

## 🚀 Getting Started

1. Clone the repo
2. Add your Firebase and OpenAI API keys
3. Run the app:
```bash
streamlit run app.py
#   B o o k l i n Q  
 